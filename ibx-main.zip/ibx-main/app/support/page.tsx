import React from "react";
import Header from "../(frontend/layouts/Header";
import Footer from "../(frontend/layouts/Footer";
import SupportMain from "../(frontend/components/SupportMain";

const page = () => {
  return (
    <>
      <Header isHome={true} />
      <SupportMain />
      <Footer />
    </>
  );
};

export default page;
