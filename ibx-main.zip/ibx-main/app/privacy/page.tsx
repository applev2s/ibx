import Header from "../(frontend/layouts/Header";

function page() {
  return (
    <div className=" min-h-screen pb-10">
      <Header isHome={true} />

      <main className="lg:max-w-[1400px] w-full mx-auto px-6 py-8">
        <div className="rounded-lg shadow-lg bg-white p-8 space-y-6">
          <h1 className="text-3xl font-bold">Privacy Policy</h1>
          <p className="text-gray-600">
            This Privacy Policy governs how <strong>rbxline.ru</strong>{" "}
            ("Operator") uses and protects the personal information you provide
            when you use our website, services, programs, or products
            (collectively, the "Site"). Your consent to this Policy applies to
            all affiliated entities of the Operator.
          </p>

          {/* Section 1 */}
          <section>
            <h2 className="text-2xl font-bold">1. General Provisions</h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                This Policy is part of the Public Offer at{" "}
                <a
                  href="https://rbxline.ru/privacy"
                  className="text-blue-600 hover:underline"
                >
                  rbxline.ru/privacy
                </a>{" "}
                and other agreements when specified.
              </li>
              <li>
                It is drafted in accordance with Federal Law No. 152-FZ "On
                Personal Data" dated July 27, 2006, and other related
                regulations.
              </li>
              <li>
                The Operator may amend this Policy; the "Last updated" date
                indicates the current version. Changes take effect upon
                publication.
              </li>
              <li>
                This Policy is governed by applicable law regarding its
                interpretation, implementation, amendment, and termination.
              </li>
            </ul>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-2xl font-bold">
              2. Personal Information Collected
            </h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                Information you provide when registering or using the Site
                (e.g., personal data, profile details).
              </li>
              <li>
                Automatically collected data via software on your device (IP
                address, cookies, browser info, device specs, access times,
                requested pages).
              </li>
              <li>Other information as permitted by Site terms.</li>
            </ul>
            <p className="text-sm text-gray-700">
              This Policy covers only data processed through the Site; we are
              not responsible for third-party sites linked from the Site.
            </p>
          </section>

          {/* Section 3 */}
          <section>
            <h2 className="text-2xl font-bold">3. Purposes of Processing</h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>Identify parties in service agreements and contracts.</li>
              <li>Provide personalized services and fulfill agreements.</li>
              <li>Send notifications and respond to your requests.</li>
              <li>Enhance Site usability and develop new features.</li>
              <li>Target advertising materials.</li>
              <li>
                Conduct statistical and research analyses on anonymized data.
              </li>
            </ul>
          </section>

          {/* Section 4 */}
          <section>
            <h2 className="text-2xl font-bold">4. Data Sharing Conditions</h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                We keep your data confidential unless you voluntarily share it
                publicly.
              </li>
              <li>
                We may share data with third parties when:
                <ol className="list-decimal pl-5 space-y-1">
                  <li>You consent.</li>
                  <li>Required to provide a service or fulfill a contract.</li>
                  <li>Necessary for Site operation.</li>
                  <li>Mandated by law.</li>
                  <li>
                    Part of a business transfer (merger, acquisition), with
                    obligations transferred to the acquirer.
                  </li>
                  <li>
                    Protecting the Site's or third parties' rights if you
                    violate Site terms or this Policy.
                  </li>
                  <li>
                    Providing anonymized data for research or services on behalf
                    of the Site.
                  </li>
                </ol>
              </li>
            </ul>
          </section>

          {/* Section 5 */}
          <section>
            <h2 className="text-2xl font-bold">
              5. Updating and Deleting Data
            </h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                You may update or supplement your personal data at any time via
                the "Contacts" section.
              </li>
              <li>
                Certain data storage requirements may apply by law, limiting
                deletion for specified periods.
              </li>
            </ul>
          </section>

          {/* Section 6 */}
          <section>
            <h2 className="text-2xl font-bold">6. Cookies</h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                We use cookies to personalize services, target ads, collect
                stats, and improve the Site.
              </li>
              <li>
                You may disable or delete cookies via your browser settings.
              </li>
              <li>Some services may require cookie acceptance to function.</li>
              <li>
                Cookie structure and parameters are determined by the Site and
                may change without notice.
              </li>
              <li>
                Counters may analyze cookie data to ensure Site operability;
                parameters may change without notice.
              </li>
            </ul>
          </section>

          {/* Section 7 */}
          <section>
            <h2 className="text-2xl font-bold">7. Data Protection Measures</h2>
            <p className="text-sm text-gray-700">
              We implement organizational and technical measures to protect your
              personal data from unauthorized access, alteration, disclosure,
              and other illegal actions.
            </p>
          </section>

          {/* Section 8 */}
          <section>
            <h2 className="text-2xl font-bold">8. Policy Changes</h2>
            <p className="text-sm text-gray-700">
              The Site may update this Policy; the "Last updated" date will
              reflect the current version. Changes take effect upon posting. The
              latest version is always at{" "}
              <a
                href="https://rbxline.ru/privacy"
                className="text-blue-600 hover:underline"
              >
                rbxline.ru/privacy
              </a>
              .
            </p>
          </section>

          {/* Section 9 */}
          <section>
            <h2 className="text-2xl font-bold">9. Contact Information</h2>
            <p className="text-sm text-gray-700">
              For questions or requests regarding this Policy or your personal
              data, contact us via private message in our VK group:{" "}
              <a
                href="https://vk.com/rbxline"
                className="text-blue-600 hover:underline"
              >
                vk.com/rbxline
              </a>
              .
            </p>
          </section>

          <p className="text-sm text-gray-500 mt-8 border-t pt-4">
            Last updated: May 17, 2025
          </p>
        </div>
      </main>
    </div>
  );
}

export default page;
