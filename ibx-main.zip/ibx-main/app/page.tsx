import AdvantagesSection from "./(frontend/components/AdvantagesSection";
import HeroSection from "./(frontend/components/HomeHero";
import PaymentInterface from "./(frontend/components/PaymentInterface";
import Footer from "./(frontend/layouts/Footer";
import Header from "./(frontend/layouts/Header";

export default function Home() {
  return (
    <>
      <Header isHome={false} />
      <main>
        <HeroSection />
        <PaymentInterface />
        <AdvantagesSection />
      </main>
      <Footer />
    </>
  );
}
