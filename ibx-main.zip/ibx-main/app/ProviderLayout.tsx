"use client";
import React, { useEffect } from "react";
import "aos/dist/aos.css";
import AOS from "aos";
import RotatingCube from "./(frontend/layouts/RotatingCube";
import LoadingScreen from "./(frontend/utils/LoadingScreen";

const ProviderLayout = ({ children }: { children: React.ReactNode }) => {
  useEffect(() => {
    AOS.init({
      duration: 800,
      once: true,
    });
  }, []);
  return (
    <React.Fragment>
      <LoadingScreen>{children}</LoadingScreen>
    </React.Fragment>
  );
};

export default ProviderLayout;
