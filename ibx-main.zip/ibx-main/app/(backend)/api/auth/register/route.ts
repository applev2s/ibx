// get user
export async function POST(request: Request) {
  try {
    const data = await request.json();
    return Response.json(data);
  } catch (error) {
    return Response.json(error);
  }
}
