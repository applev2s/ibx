import Image from "next/image";
import { ArrowDown, Wifi, ShoppingBag, ShoppingCart } from "lucide-react";
import "./css/hero-section.css";
import { IoBagOutline } from "react-icons/io5";
import Link from "next/link";

export default function HeroSection() {
  return (
    <section className="relative w-full   overflow-hidden">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          {/* Text Content - Left Side */}
          <div className="w-full md:w-1/2 space-y-6 text-white z-10 order-2 md:order-1">
            <h2
              data-aos="flip-left"
              className="neon-text  text-3xl md:text-4xl font-bold"
            >
              Low Prices -
            </h2>
            <h1
              data-aos="fade-right"
              className="text-4xl md:text-6xl font-bold"
            >
              Happy Customers
            </h1>

            {/* Stats Bar */}
            <div
              data-aos="fade-down"
              className="bg-zinc-800/80 border bo rounded-lg p-4 mt-8"
            >
              <div className="flex flex-col sm:flex-row justify-between items-center divide-y sm:divide-y-0 sm:divide-x di/30">
                <div className="flex items-center gap-3 px-4 py-2 w-full sm:w-1/3 justify-center">
                  <Wifi className=" h-10 w-10" />
                  <div className="text-center">
                    <p id="neonNumber" className="  font-bold text-xl">
                      136
                    </p>
                    <p className="text-sm text-gray-300">Online |</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 px-4 py-2 w-full sm:w-1/3 justify-center">
                  <IoBagOutline className=" h-10 w-10" />
                  <div className="text-center">
                    <p id="neonNumber" className="  font-bold text-xl">
                      44 201 04
                    </p>
                    <p className="text-sm text-gray-300">Bought R$</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 px-4 py-2 w-full sm:w-1/3 justify-center">
                  <ShoppingCart className=" h-10 w-10" />
                  <div className="text-center">
                    <p id="neonNumber" className=" font-bold text-xl">
                      96 837
                    </p>
                    <p className="text-sm text-gray-300">Orders</p>
                  </div>
                </div>
              </div>
            </div>

            <p data-aos="fade-up" className="text-xl md:text-2xl mt-6">
              Let's go shopping!
            </p>

            <a
              href="#advantages"
              className="flex  w-full justify-center md:justify-start pt-4"
            >
              <ArrowDown className="text-white h-8 w-8 animate-bounce cursor-pointer" />
            </a>
          </div>

          {/* Image - Right Side */}
          <div className="w-full md:w-1/2 relative order-1 md:order-2">
            <div className="aspect-square max-w-md mx-auto relative">
              <div className="absolute inset-0 bg-primary rounded-full opacity-70 blur-lg"></div>
              <div className="relative z-10">
                <Image
                  src="/images/man.png"
                  alt="Gaming Character"
                  width={500}
                  height={500}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
