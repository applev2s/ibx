"use client";
import {
  User,
  Shield,
  RussianRuble,
  AlertCircle,
  ChevronRight,
  Diamond,
  Info,
} from "lucide-react";
import Link from "next/link";
import AuthModal from "../layouts/AuthModal";
import { useEffect, useState } from "react";

function PaymentInterface() {
  const [paymentMethod, setPaymentMethod] = useState("");
  const [username, setUsername] = useState("");
  const [amount, setAmount] = useState("");
  const [price, setPrice] = useState("$0.00");
  const [activeMethod, setActiveMethod] = useState("paypal");
  const rate = 0.006;

  useEffect(() => {
    const amt = Number.parseFloat(amount) || 0;
    const calculatedPrice = (amt * rate).toFixed(2);
    setPrice(`$${calculatedPrice}`);
  }, [amount]);

  const handleContinue = () => {
    // This would open the place modal in the original code
    alert("Continue button clicked - would open place modal");
  };
  return (
    <div className="min-h-screen w-full  p-4 md:p-6 lg:p-8 flex flex-col items-center justify-center">
      <div className="w-full max-w-6xl mx-auto " data-aos="flip-left">
        <div className="  flex-col justify-center items-center lg:flex-row gap-6">
          {/* Left Column */}
          {/* <section id="section2" className="py-12">
            <div className="bg-[rgba(30,30,30,0.8)] border-2 border-[#3399ff] rounded-lg max-w-2xl mx-auto p-6">
              <h2 className="text-xl mb-4 text-[#3399ff]">ibx Buy</h2>

              <div className="flex items-center bg-[#111] rounded-md p-3 mb-4">
                <User className="w-8 h-8 text-white" />
                <input
                  id="username"
                  type="text"
                  placeholder="Roblox Username"
                  className="flex-1 ml-3 bg-transparent border-none text-white text-base"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>

              <div className="flex items-center bg-[#111] rounded-md p-3 mb-4">
                <Diamond className="w-8 h-8 text-white" />
                <input
                  id="amount"
                  type="number"
                  placeholder="Amount (e.g. 1000)"
                  min="1"
                  className="flex-1 ml-3 bg-transparent border-none text-white text-base"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>

              <div className="flex items-center bg-[#111] rounded-md p-3 mb-2">
                <Info className="w-8 h-8 text-white" />
                <span
                  id="priceDisplay"
                  className="text-[#3399ff] font-bold text-base ml-3"
                >
                  {price}
                </span>
              </div>

              <div className="text-[#f55] text-sm text-center mb-4">
                Robux will be delivered 5 days after purchase.
              </div>

              <button
                id="continueBtn"
                className="w-full py-3 bg-[#3399ff] text-black border-none rounded-md font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!amount || Number.parseFloat(amount) < 1}
                onClick={handleContinue}
              >
                Continue
              </button>
            </div>
          </section> */}
          <section id="section2" className="py-12">
            <div className="bg-[rgba(30,30,30,0.8)] border-2 border-[#3399ff] rounded-lg max-w-[600px] mx-auto p-6">
              <h2 className="text-xl mb-4 text-[#3399ff]">ibx Buy</h2>

              <div className="flex items-center bg-[#111] rounded-md p-3 mb-4">
                <User className="w-8 h-8 text-white" />
                <input
                  id="username"
                  type="text"
                  placeholder="Roblox Username"
                  className="flex-1 ml-3 bg-transparent border-none text-white text-base"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>

              <div className="flex items-center bg-[#111] rounded-md p-3 mb-4">
                <img
                  src="/images/sqr-ico2.webp"
                  className="w-8 h-8 text-white"
                />
                <input
                  id="amount"
                  type="number"
                  placeholder="Amount (e.g. 1000)"
                  min="1"
                  className="flex-1 ml-3 bg-transparent border-none text-white text-base"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>

              <div className="flex items-center bg-[#111] rounded-md p-3 mb-2">
                <Info className="w-8 h-8 text-white" />
                <span
                  id="priceDisplay"
                  className="text-[#3399ff] font-bold text-base ml-3"
                >
                  {price}
                </span>
              </div>

              <div className="text-[#f55] text-sm text-center mb-4">
                Robux will be delivered 5 days after purchase.
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                <button
                  type="button"
                  className={`flex-1 flex items-center justify-center gap-2 p-2 bg-[#333] ${
                    activeMethod === "paypal"
                      ? "border-[#3399ff] text-[#3399ff] bg-[rgba(0,0,0,0.6)]"
                      : "border-transparent text-white"
                  } border-2 rounded transition-colors duration-200 min-w-[45%]`}
                  onClick={() => setActiveMethod("paypal")}
                >
                  <img
                    src="/images/paypal-logosa.png"
                    alt="PayPal logo"
                    className="w-5 h-auto"
                  />
                  PayPal
                </button>

                <button
                  type="button"
                  className={`flex-1 flex items-center justify-center gap-2 p-2 bg-[#333] ${
                    activeMethod === "stripe"
                      ? "border-[#3399ff] text-[#3399ff] bg-[rgba(0,0,0,0.6)]"
                      : "border-transparent text-white"
                  } border-2 rounded transition-colors duration-200 min-w-[45%]`}
                  onClick={() => setActiveMethod("stripe")}
                >
                  <img
                    src="/images/stripe-logos.png"
                    alt="Stripe logo"
                    className="w-5 h-auto"
                  />
                  Stripe
                </button>

                <button
                  type="button"
                  className={`flex-1 flex items-center justify-center gap-2 p-2 bg-[#333] ${
                    activeMethod === "crypto"
                      ? "border-[#3399ff] text-[#3399ff] bg-[rgba(0,0,0,0.6)]"
                      : "border-transparent text-white"
                  } border-2 rounded transition-colors duration-200 min-w-[45%]`}
                  onClick={() => setActiveMethod("crypto")}
                >
                  <img
                    src="/images/cryptoaa-logo.png"
                    alt="Crypto logo"
                    className="w-5 h-auto"
                  />
                  Crypto
                </button>
              </div>

              <button
                id="continueBtn"
                className="w-full py-3 bg-[#3399ff] text-black border-none rounded-md font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!amount || Number.parseFloat(amount) < 1}
                onClick={handleContinue}
              >
                Continue
              </button>
            </div>
          </section>
          {/* Right Column */}
          {/* <div className="flex-1 bg-zinc-800 rounded-3xl p-6">
            <h2 className="text-white text-xl md:text-2xl font-medium mb-4">
              Выберите способ оплаты:
            </h2>
            <div className="h-0.5 bg-white/20 w-full mb-6"></div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button
                onClick={() => setPaymentMethod(1)}
                className={`${
                  paymentMethod === 1
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 relative">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-red-500 rounded-md flex items-center justify-center">
                    <span className="text-white text-xs font-bold">СБП</span>
                  </div>
                </div>
                <span className="text-white text-lg">СБП</span>
              </button>

              <button
                onClick={() => setPaymentMethod(2)}
                className={`${
                  paymentMethod === 2
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 bg-orange-500 border-2 border-transparent  rounded-full flex items-center justify-center">
                  <span className="text-white text-lg font-bold">₿</span>
                </div>
                <span className="text-white text-lg">Криптовалюта</span>
              </button>

              <button
                onClick={() => setPaymentMethod(3)}
                className={`${
                  paymentMethod === 3
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center">
                  <div className="w-5 h-5 bg-black rounded-full"></div>
                </div>
                <span className="text-white text-lg">Билайн (от 100р)</span>
              </button>

              <button
                onClick={() => setPaymentMethod(4)}
                className={`${
                  paymentMethod === 4
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                  <div className="w-4 h-4 border-2 border-white rounded-full"></div>
                </div>
                <span className="text-white text-lg">Мегафон (от 100р)</span>
              </button>

              <button
                onClick={() => setPaymentMethod(5)}
                className={`${
                  paymentMethod === 5
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 bg-black rounded-md flex items-center justify-center">
                  <span className="text-white text-xs font-bold">TELE2</span>
                </div>
                <span className="text-white text-lg">Теле2 (от 100р)</span>
              </button>

              <button
                onClick={() => setPaymentMethod(6)}
                className={`${
                  paymentMethod === 6
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-md"></div>
                <span className="text-white text-lg">Карта 2 (от 1000р)</span>
              </button>

              <button
                onClick={() => setPaymentMethod(7)}
                className={`${
                  paymentMethod === 7
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 bg-blue-800 rounded-full flex items-center justify-center">
                  <svg
                    className="w-5 h-5 text-white"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M12 2C6.477 2 2 6.477 2 12C2 17.523 6.477 22 12 22C17.523 22 22 17.523 22 12C22 6.477 17.523 2 12 2Z" />
                  </svg>
                </div>
                <span className="text-white text-lg">Steam (от 50р)</span>
              </button>
            </div>
          </div> */}

          {/* <div className="flex-1 bg-zinc-800 rounded-3xl p-6">
            <h2 className="text-white text-xl md:text-2xl font-medium mb-4">
              Выберите способ оплаты:
            </h2>
            <div className="h-0.5 bg-white/20 w-full mb-6"></div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-lg mx-auto">
              <button
                onClick={() => setPaymentMethod("strpe")}
                className={`${
                  paymentMethod === "strpe"
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors  justify-center  rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 relative">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-red-500 rounded-md flex items-center justify-center">
                    <img src="/images/stripe-logos.png" alt="Stripe logo" />
                  </div>
                </div>
                <span className="text-white text-lg">Stripe</span>
              </button>
              <button
                onClick={() => setPaymentMethod("paypal")}
                className={`${
                  paymentMethod === "paypal"
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors  justify-center  rounded-xl p-4 method-btn border-2 border-transparent  flex items-center gap-3 cursor-pointer`}
              >
                <div className="w-8 h-8 relative">
                  <div className="w-8 h-8  rounded-md flex items-center justify-center">
                    <img src="/images/paypal-logosa.png" alt="Stripe logo" />
                  </div>
                </div>
                <span className="text-white text-lg">Paypal</span>
              </button>
              <button
                onClick={() => setPaymentMethod("crypto")}
                className={`${
                  paymentMethod === "crypto"
                    ? "bg-zinc-500  active"
                    : "bg-zinc-700 hover:bg-zinc-600"
                }   transition-colors rounded-xl p-4 method-btn border-2 border-transparent justify-center flex items-center gap-3 cursor-pointer col-span-2`}
              >
                <div className="w-8 h-8 relative">
                  <div className="w-8 h-8  rounded-md flex items-center justify-center">
                    <img src="/images/cryptoaa-logo.png" alt="Stripe logo" />
                  </div>
                </div>
                <span className="text-white text-lg">Crypto</span>
              </button>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
}

export default PaymentInterface;
