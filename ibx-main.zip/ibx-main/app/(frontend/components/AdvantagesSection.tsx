import { Diamond, Headphones, MessageCircle, Smile } from "lucide-react";
import Image from "next/image";

export default function AdvantagesSection() {
  return (
    <section id="advantages" className="relative w-full  overflow-hidden">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          <div className="absolute inset-0 opacity-10">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="absolute w-12 h-12 rotate-45 bg-gray-400"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  opacity: 0.1,
                }}
              />
            ))}
          </div>

          <div className="container mx-auto px-4">
            <h2 className="colored_heading font-bold mb-12">Our advantages</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Feature 1 */}
              <div
                data-aos="fade-left"
                className="relative p-6 rounded-md border border-transparent bg-[#1e1e1e]"
              >
                {/* Neon border effect */}
                <div className="absolute inset-0 rounded-lg border-2 border-[#ffffff] shadow-[0_0_15px_rgba(255,255,255,0.7)] pointer-events-none"></div>

                <div className="flex flex-col items-center text-center">
                  <Diamond className="w-12 h-12 text-white mb-4" />
                  <h3 className="text-[#ffffff] text-xl font-medium mb-2">
                    The best price on the market
                  </h3>
                  <p className="text-white">
                    {/* «Наши клиенты покупают только по лучшей цене!» */}
                    "Our customers buy only at the best price!"
                  </p>
                </div>
              </div>

              {/* Feature 2 */}
              <div
                data-aos="fade-up"
                className="relative p-6 rounded-md border border-transparent bg-[#1e1e1e]"
              >
                {/* Neon border effect */}
                <div className="absolute inset-0 rounded-lg border-2 border-[#ffffff] shadow-[0_0_15px_rgba(255,255,255,0.7)] pointer-events-none"></div>

                <div className="flex flex-col items-center text-center">
                  <Headphones className="w-12 h-12 text-white mb-4" />
                  <h3 className="text-[#ffffff] text-xl font-medium mb-2">
                    Fast support
                  </h3>
                  <p className="text-white">
                    "Our staff is always happy to help you!"
                  </p>
                </div>
              </div>

              {/* Feature 3 */}
              <div
                data-aos="fade-up"
                className="relative p-6 rounded-md border border-transparent bg-[#1e1e1e]"
              >
                {/* Neon border effect */}
                <div className="absolute inset-0 rounded-lg border-2 border-[#ffffff] shadow-[0_0_15px_rgba(255,255,255,0.7)] pointer-events-none"></div>

                <div className="flex flex-col items-center text-center">
                  <MessageCircle className="w-12 h-12 text-white mb-4" />
                  <h3 className="text-[#ffffff] text-xl font-medium mb-2">
                    Positive reviews
                  </h3>
                  <p className="text-white">
                    "Everyone can read other people's reviews!"
                  </p>
                </div>
              </div>

              {/* Feature 4 */}
              <div
                data-aos="fade-right"
                className="relative p-6 rounded-md border border-transparent bg-[#1e1e1e]"
              >
                {/* Neon border effect */}
                <div className="absolute inset-0 rounded-lg border-2 border-[#ffffff] shadow-[0_0_15px_rgba(255,255,255,0.7)] pointer-events-none"></div>

                <div className="flex flex-col items-center text-center">
                  <Smile className="w-12 h-12 text-white mb-4" />
                  <h3 className="text-[#ffffff] text-xl font-medium mb-2">
                    Happy customers
                  </h3>
                  <p className="text-white">
                    "Our clients trust us and come back again!"
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
