"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { FaTelegramPlane } from "react-icons/fa";
import { BsSendFill } from "react-icons/bs";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const SupportMain = () => {
  const [offset, setOffset] = useState(0);
  const [selectedReviews, setSelectedReviews] = useState<number[]>([]);
  const [openFaqs, setOpenFaqs] = useState<number[]>([]);

  const reviews = [
    {
      id: 1,
      handle: "#cryzeverity",
      role: "Buyer",
      avatar: "/images/avatars/cryzeverity.jpg",
      content:
        "Very pleased – the first account was great, the second one I had to rebuy, but only 30₽. Fast support too.",
    },
    {
      id: 2,
      handle: "#Qwriixx",
      role: "Buyer",
      avatar: "/images/avatars/qwriixx.jpg",
      content:
        "I am very happy, I went into adopt from the first account, I got a turtle in inva, the only downside is that you don't have that account anymore, well, that's not a problem because I transferred the turtle and literally bought it for 30 rubles.",
    },
    {
      id: 3,
      handle: "#btccolazxc",
      role: "Buyer",
      avatar: "/images/avatars/btccolazxc.jpg",
      content:
        "Cookies pay for themselves, site is clean, UI nice, prices are the best I've seen.",
    },
    {
      id: 4,
      handle: "#btccolazxc",
      role: "Buyer",
      avatar: "/images/avatars/qwriixx.jpg",
      content:
        "I am very happy, I went into adopt from the first account, I got a turtle in inva, the only downside is that you don't have that account anymore, well, that's not a problem because I transferred the turtle and literally bought it for 30 rubles.",
    },
  ];

  const faqs = [
    {
      id: 1,
      question: "Will the account remain forever?",
      answer:
        "No, an account obtained via cookies almost never remains permanently available.",
    },
    {
      id: 2,
      question: "Why is it so cheap?",
      answer:
        "We keep market-low prices by optimizing quality controls and overhead—best value guaranteed.",
    },
    {
      id: 3,
      question: "How can I use purchased cookies?",
      answer:
        "Simply import the cookies into your browser to log in and explore games, items, skins, and more.",
    },
    {
      id: 4,
      question: "Can I be sure that cookies still work?",
      answer:
        "If they fail, we'll provide a replacement—just reach out and we'll sort it out.",
    },
    {
      id: 5,
      question:
        // "What should I do if the cookie worked immediately after purchase, but stopped working after some time?",
        "What should I do if the cookie ?",

      answer:
        "Our warranty covers working cookies at delivery time only; later failures are not covered.",
    },
    {
      id: 6,
      question: "What guarantees do you provide?",
      answer:
        "You might uncover rare in-game items—join our Telegram channel for updates.",
    },
  ];

  const handlePrevClick = () => {
    setOffset((prev) => Math.min(prev + 1, 0));
  };

  const handleNextClick = () => {
    const maxOffset = -(Math.ceil(reviews.length / 3) - 1);
    setOffset((prev) => Math.max(prev - 1, maxOffset));
  };

  const toggleReviewSelection = (id: number) => {
    setSelectedReviews((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleFaq = (id: number) => {
    setOpenFaqs((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="  text-[#F0F0F0] font-sans min-h-screen flex flex-col">
      {/* HEADER */}
      <main className="flex-1 w-[90%] max-w-[1200px] mx-auto py-4">
        {/* REVIEWS */}
        <section id="reviews" className="mb-8">
          <h2 className="mb-4 text-xl font-semibold">
            🥤 Reviews from our customers
          </h2>
          <Carousel className="w-full max-w-7xl mx-auto">
            <CarouselContent className="-ml-4">
              {reviews.map((review) => (
                <CarouselItem
                  key={review.id}
                  className="pl-4 basis-full sm:basis-1/2 lg:basis-1/3"
                >
                  <div
                    className={`bg-[rgba(255,255,255,0.1)] backdrop-blur-md border border-[#00E5FF] rounded-lg p-4 h-full cursor-pointer transition-transform duration-300 hover:translate-y-[-8px] relative ${
                      selectedReviews.includes(review.id)
                        ? "shadow-[0_0_8px_#008BCE]"
                        : ""
                    }`}
                    onClick={() => toggleReviewSelection(review.id)}
                  >
                    {/* {selectedReviews.includes(review.id) && (
                      <div className="absolute top-2 right-2 bg-[#008BCE] text-[#010101] w-6 h-6 flex items-center justify-center rounded-full text-base shadow-[0_0_6px_rgba(0,229,255,0.7)]">
                        ✓
                      </div>
                    )} */}
                    <div className="flex items-center mb-4">
                      <Image
                        src={review.avatar || "/placeholder.svg"}
                        alt=""
                        width={48}
                        height={48}
                        className="rounded-full border-2 border-[#00E5FF] mr-4"
                      />
                      <div className="flex flex-col">
                        <div className="text-xl font-semibold">
                          {review.handle}
                        </div>
                        <div className="text-sm text-[rgba(255,255,255,0.7)]">
                          {review.role}
                        </div>
                      </div>
                    </div>
                    <p className="text-base leading-relaxed">
                      {review.content}
                    </p>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>

            {/* Arrows with custom color */}
            <CarouselPrevious className="text-[#00E5FF] border-[#00E5FF] hover:bg-[#00E5FF]/10" />
            <CarouselNext className="text-[#00E5FF] border-[#00E5FF] hover:bg-[#00E5FF]/10" />
          </Carousel>
        </section>

        {/* SUPPORT FORM */}
        <section className="text-center mb-8">
          <h1 className="text-3xl mb-4 tracking-wide font-bold">
            Having a Problem?
          </h1>
          <form
            action="https://wilddragon.ru/support"
            method="POST"
            className="max-w-[600px] mx-auto flex flex-col"
          >
            <input
              type="text"
              name="name"
              className="w-full bg-transparent border-2 border-[#00E5FF] rounded-lg py-3 px-3 text-[#F0F0F0] shadow-[0_0_6px_rgba(0,229,255,0.7)] mb-4 text-base transition-all duration-300 focus:outline-none focus:border-[#008BCE] focus:shadow-[0_0_8px_rgba(0,229,255,0.7)]"
              placeholder="Your Name"
              required
            />
            <input
              type="email"
              name="email"
              className="w-full bg-transparent border-2 border-[#00E5FF] rounded-lg py-3 px-3 text-[#F0F0F0] shadow-[0_0_6px_rgba(0,229,255,0.7)] mb-4 text-base transition-all duration-300 focus:outline-none focus:border-[#008BCE] focus:shadow-[0_0_8px_rgba(0,229,255,0.7)]"
              placeholder="Your Email"
              required
            />
            <textarea
              name="message"
              className="w-full bg-transparent border-2 border-[#00E5FF] rounded-lg py-3 px-3 text-[#F0F0F0] shadow-[0_0_6px_rgba(0,229,255,0.7)] mb-4 text-base transition-all duration-300 focus:outline-none focus:border-[#008BCE] focus:shadow-[0_0_8px_rgba(0,229,255,0.7)] resize-y min-h-[120px]"
              placeholder="Describe your issue…"
              required
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center bg-transparent border-2 border-[#00E5FF] rounded-lg text-[#00E5FF] py-3 px-3 text-base shadow-[0_0_8px_rgba(0,229,255,0.7)] cursor-pointer transition-shadow gap-x-3 duration-300 hover:shadow-[0_0_14px_rgba(0,229,255,0.7)]"
            >
              <BsSendFill size={20} />
              Submit
            </button>
          </form>
        </section>

        {/* FAQ */}
        <section className="mb-8">
          <div id="reviews">
            <h2>❔ Answers to frequently asked questions</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {faqs.map((faq) => (
              <div
                key={faq.id}
                className={`bg-[rgba(255,255,255,0.1)] backdrop-blur-md border border-[#00E5FF] rounded-lg overflow-hidden transition-all duration-300 hover:translate-y-[-6px] ${
                  openFaqs.includes(faq.id)
                    ? "bg-[rgba(0,229,255,0.15)] border-[#008BCE] shadow-[0_0_12px_#008BCE]"
                    : ""
                }`}
              >
                <div
                  className="flex justify-between items-center p-4 cursor-pointer transition-all duration-300 hover:bg-[rgba(0,229,255,0.1)]"
                  onClick={() => toggleFaq(faq.id)}
                >
                  <span
                    className={`font-bold transition-colors duration-300 ${
                      openFaqs.includes(faq.id) ? "text-[#00E5FF]" : ""
                    }`}
                  >
                    {faq.question}
                  </span>
                  <span
                    className={`flex items-center justify-center w-8 h-8 rounded-full bg-[#00E5FF] text-[#010101] text-xl shadow-[0_0_6px_rgba(0,229,255,0.7)] transition-all duration-300 ml-4 leading-none ${
                      openFaqs.includes(faq.id)
                        ? "bg-[#008BCE] text-2xl shadow-[0_0_8px_#008BCE]"
                        : ""
                    }`}
                  >
                    {openFaqs.includes(faq.id) ? "-" : "+"}
                  </span>
                </div>
                <div
                  className={`px-4 pb-4 text-[0.95rem] leading-relaxed ${
                    openFaqs.includes(faq.id) ? "block" : "hidden"
                  }`}
                >
                  {faq.id === 6 ? (
                    <>
                      You might uncover rare in-game items—join our{" "}
                      <a
                        href="https://t.me/wilddragonru"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#008BCE] no-underline transition-all duration-300 hover:text-[#00E5FF] hover:shadow-[0_0_8px_rgba(0,229,255,0.7)]"
                      >
                        Telegram channel
                      </a>{" "}
                      for updates.
                    </>
                  ) : (
                    faq.answer
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* MORE REVIEWS CTA */}
        <section>
          <h3 className="text-center text-xl mb-4">
            More reviews in{" "}
            <a
              href="https://t.me/wilddragonru"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#008BCE] no-underline transition-all duration-300 hover:text-[#00E5FF]  "
            >
              Telegram
            </a>
          </h3>
          <div className="flex justify-center">
            <button
              className="inline-flex items-center justify-center gap-x-2 bg-transparent border-2 border-[#00E5FF] rounded-lg text-[#00E5FF] py-3 px-4 text-base shadow-[0_0_8px_rgba(0,229,255,0.7)] cursor-pointer transition-shadow duration-300 hover:shadow-[0_0_14px_rgba(0,229,255,0.7)]"
              onClick={() => window.open("https://t.me/wilddragonru", "_blank")}
            >
              <FaTelegramPlane size={20} />
              Telegram Channel
            </button>
          </div>
        </section>
      </main>
    </div>
  );
};

export default SupportMain;
