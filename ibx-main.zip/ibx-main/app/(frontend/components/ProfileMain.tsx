"use client";

import { useState } from "react";
import Image from "next/image";
import {
  FaCartArrowDown,
  FaInfoCircle,
  FaSortNumericUpAlt,
} from "react-icons/fa";
import { IoMdSettings } from "react-icons/io";
import Header from "../layouts/Header";
import Footer from "../layouts/Footer";

function ProfileMain() {
  const [activeTab, setActiveTab] = useState("purchases");

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
  };

  return (
    <div className=" bg-[#0a0a0a] text-[#ddd] font-sans">
      <Header isHome={true} />
      <header className="relative py-16 px-8 my-10 text-center text-white">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=1200')] bg-center bg-cover bg-no-repeat"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-[rgba(0,255,255,0.8)] to-[rgba(0,0,0,0.7)]"></div>
        <div className="relative z-10">
          <h1 className="text-4xl mb-2">#jedediah_jerde977</h1>
          <div className="text-[#c0c0c0] mb-6">User</div>
          <div className="inline-flex items-center gap-4">
            <div className="flex items-center gap-1 bg-[#1a1a1a] px-3 py-2 rounded-md text-[#00ff00]">
              <FaSortNumericUpAlt size={18} />
              <span>0</span>
            </div>
            <button
              onClick={() => alert("Log out")}
              className="bg-[#ee0000] cursor-pointer text-white px-4 py-2 rounded-md font-bold"
            >
              Log out
            </button>
          </div>
        </div>
      </header>
      {/* Main Content */}
      <div className="min-h-[60vh] ">
        <section className="max-w-5xl mx-auto my-12 bg-[#121212] rounded-2xl p-8 shadow-[0_10px_20px_rgba(0,0,0,0.5)]">
          {/* Tabs */}
          <div className="md:flex justify-center gap-4 mb-8  ">
            <button
              onClick={() => handleTabClick("purchases")}
              className={` w-full mb-3 md:mb-0 md:w-auto px-5 py-2 border border-[#444] rounded-md flex items-center gap-2 transition-colors ${
                activeTab === "purchases"
                  ? "bg-[#00FFFF] text-black border-[#00FFFF]"
                  : "text-[#ccc] hover:text-black hover:border-[#00FFFF] hover:bg-[rgba(0,255,255,0.2)]"
              }`}
            >
              <FaCartArrowDown size={16} />
              Purchases
            </button>

            <button
              onClick={() => handleTabClick("settings")}
              className={`px-5 py-2 w-full md:w-auto mb-3 md:mb-0 border border-[#444] rounded-md flex items-center gap-2 transition-colors ${
                activeTab === "settings"
                  ? "bg-[#00FFFF] text-black border-[#00FFFF]"
                  : "text-[#ccc] hover:text-black hover:border-[#00FFFF] hover:bg-[rgba(0,255,255,0.2)]"
              }`}
            >
              <IoMdSettings size={16} />
              Settings
            </button>

            <button
              onClick={() => handleTabClick("info")}
              className={`px-5 py-2 w-full md:w-auto mb-3 md:mb-0 border border-[#444] rounded-md flex items-center gap-2 transition-colors ${
                activeTab === "info"
                  ? "bg-[#00FFFF] text-black border-[#00FFFF]"
                  : "text-[#ccc] hover:text-black hover:border-[#00FFFF] hover:bg-[rgba(0,255,255,0.2)]"
              }`}
            >
              <FaInfoCircle size={16} />
              Information
            </button>
          </div>

          {/* Tab Content */}
          {activeTab === "purchases" && (
            <div>
              <div className="grid grid-cols-4 bg-[#1d1d1d] p-4 rounded-lg">
                <div className="text-center font-medium text-[#bbb]">Name</div>
                <div className="text-center font-medium text-[#bbb]">
                  Content
                </div>
                <div className="text-center font-medium text-[#bbb]">
                  Order number
                </div>
                <div className="text-center font-medium text-[#bbb]">
                  Date of purchase
                </div>
              </div>
              {/* Purchase rows would go here */}
            </div>
          )}

          {activeTab === "settings" && (
            <div className="text-center">
              <h2 className="text-4xl mb-6 text-white [text-shadow:0_0_10px_rgba(0,255,255,0.7)]">
                Change nickname
              </h2>
              <input
                type="text"
                placeholder="Max 20 characters"
                maxLength={20}
                className="py-3 px-4 w-[250px] rounded-md bg-[#1a1a1a] text-white border-none"
              />
              <button
                onClick={() => alert("Change nickname")}
                className="ml-2 py-3 px-4 cursor-pointer rounded-md bg-[#00FFFF] text-black border-none shadow-[0_0_10px_#00FFFF]"
              >
                ✓
              </button>
            </div>
          )}

          {activeTab === "info" && (
            <div className="text-center text-[#ddd]">
              <h2 className="text-4xl mb-4 text-white [text-shadow:0_0_10px_rgba(0,255,255,0.7)]">
                Account Information
              </h2>
              <p className="my-2">
                Registered since{" "}
                <span className="text-[#00FFFF]">05/17/2025 10:05:49</span>
              </p>
              <p className="my-2">
                Total purchases for <span className="text-[#00FFFF]">0</span>{" "}
                dollar
              </p>
            </div>
          )}
        </section>
      </div>
      <Footer />
    </div>
  );
}

export default ProfileMain;
