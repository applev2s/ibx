import React from "react";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { X } from "lucide-react";
import { FaDiscord, FaEnvelope, FaGoogle } from "react-icons/fa";
const AuthModal = ({ children }: { children: React.ReactNode }) => {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{children}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-center mb-4">
            <span className="colored_heading">Authentication</span>
          </AlertDialogTitle>
          <AlertDialogDescription className="px-[10%] flex flex-col space-y-5">
            <>
              <button className="w-full p-3 cursor-pointer text-center rounded-xl  gap-4 bg-primary flex items-center justify-center text-background font-semibold hover:bg-opacity-80 transition-all duration-150 ease-in-out">
                <FaGoogle className="w-6 h-6" />
                <span className="text-lg">Login with Google</span>
              </button>
              <button className="w-full p-3 cursor-pointer text-center rounded-xl  gap-4 bg-primary flex items-center justify-center text-background font-semibold hover:bg-opacity-80 transition-all duration-150 ease-in-out">
                <FaDiscord className="w-7 h-7" />
                <span className="text-lg">Login with Discord</span>
              </button>
              <button className="w-full  p-3 cursor-pointer rounded-xl text-center gap-4 bg-primary flex items-center justify-center text-background font-semibold hover:bg-opacity-80 transition-all duration-150 ease-in-out">
                <FaEnvelope className="w-6 h-6" />
                <span className="text-lg">Login with Email</span>
              </button>
            </>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="absolute -top-3 hover:text-background text-background  -right-3 bg-transparent rounded-full bg-white font-semibold border-none hover:bg-white   ">
            <X />
          </AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AuthModal;
