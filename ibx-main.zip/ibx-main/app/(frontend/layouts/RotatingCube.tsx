// components/ThreeBackground.tsx (or .js if you're not using TS)
"use client";

import { useEffect } from "react";
import * as THREE from "three";

export default function RotatingCube() {
  useEffect(() => {
    const old = document.getElementById("bgCanvas");
    if (old) old.remove();

    const canvas = document.createElement("canvas");
    canvas.id = "bgCanvas";
    canvas.style.position = "fixed";
    canvas.style.top = "0";
    canvas.style.left = "0";
    canvas.style.zIndex = "-1"; // So it stays in the background
    document.body.appendChild(canvas);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 5;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);

    const geo = new THREE.BoxGeometry(2, 2, 2, 8, 8, 8);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x3399ff,
      transparent: true,
      opacity: 0.8,
    });
    const cube = new THREE.Mesh(geo, mat);
    scene.add(cube);

    const animate = () => {
      requestAnimationFrame(animate);
      cube.rotation.x += 0.01;
      cube.rotation.y += 0.01;
      renderer.render(scene, camera);
    };
    animate();

    // Optional: handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", handleResize);

    // Cleanup
    return () => {
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
      canvas.remove();
    };
  }, []);

  return null; // Since canvas is attached manually
}
