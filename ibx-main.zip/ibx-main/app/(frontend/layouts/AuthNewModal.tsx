"use client";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { X } from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import { FaDiscord, FaEnvelope, FaGoogle } from "react-icons/fa";
const AuthNewModal = ({ children }: { children: React.ReactNode }) => {
  const [method, setMethod] = useState("");
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{children}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-center mb-4">
            <span className="colored_heading">Authentication</span>
          </AlertDialogTitle>
          <AlertDialogDescription className="px-[10%] flex flex-col space-y-5">
            <div>
              <div className="methods">
                <button
                  onClick={() => setMethod("paypal")}
                  type="button"
                  className={`py-2 px-3 border-2  cursor-pointer w-full flex justify-center items-center gap-4 bg-gray-700 rounded ${
                    method === "paypal"
                      ? "border-secondary"
                      : "border-transparent"
                  }`}
                >
                  <img
                    className="w-6"
                    src="/images/paypal-logosa.png"
                    alt="PayPal logo"
                  />{" "}
                  <span className="text-white">PayPal</span>
                </button>
                <button
                  onClick={() => setMethod("stripe")}
                  type="button"
                  className={`py-2 px-3 border-2  cursor-pointer w-full flex justify-center items-center gap-4 bg-gray-700 rounded ${
                    method === "stripe"
                      ? "border-secondary"
                      : "border-transparent"
                  }`}
                >
                  <img
                    className="w-6"
                    src="/images/stripe-logos.png"
                    alt="Stripe logo"
                  />{" "}
                  <span className="text-white">Stripe</span>
                </button>
                <button
                  onClick={() => setMethod("crypto")}
                  type="button"
                  className={`py-2 border-2  cursor-pointer px-3 w-full flex justify-center items-center gap-4 bg-gray-700 rounded ${
                    method === "crypto"
                      ? "border-secondary"
                      : "border-transparent"
                  }`}
                >
                  <img
                    className="w-6"
                    src="/images/cryptoaa-logo.png"
                    alt="Crypto logo"
                  />{" "}
                  <span className="text-white">Crypto</span>
                </button>
              </div>
              <button id="continueBtn" className="btn-continue" disabled>
                Continue
              </button>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="absolute -top-3 hover:text-background text-background  -right-3 bg-transparent rounded-full bg-white font-semibold border-none hover:bg-white   ">
            <X />
          </AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AuthNewModal;
