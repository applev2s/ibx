import React from "react";
import Container from "./Container";
import Link from "next/link";
import { User2 } from "lucide-react";
import AuthModal from "./AuthModal";
import MobileMenu from "./MobileMenu";
import AuthNewModal from "./AuthNewModal";

export const menuItems = [
  {
    name: "Group",
    href: "/group",
  },
  {
    name: "Support",
    href: "/support",
  },
  {
    name: "Discord",
    href: "/discord",
  },
  {
    name: "Reviews",
    href: "/reviews",
  },
];
const Header = ({ isHome }: { isHome?: boolean }) => {
  return (
    <header className=" sticky top-0 z-50">
      {/* <Container className=" h-[100px] shadow-md md:rounded-2xl md:mt-3 bg-white px-5">
        <div className="flex h-full justify-between items-center gap-x-5 w-full">
          <div
            data-aos="fade-down-right"
            className="text-4xl text-background font-bold tracking-wide"
          >
            <span className="logo_heading">ibx</span>
          </div>
          <div className="md:hidden">
            <MobileMenu />
          </div>
          <nav data-aos="fade-down" className="hidden md:flex ">
            <ul className="flex text-background justify-between items-center gap-x-6">
              {menuItems.map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="font-semibold  text-xl tracking-wide hover:underline transition-all ease-in-out duration-100"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div
            data-aos="fade-down-left"
            className="hidden md:flex justify-end items-center h-full"
          >
            <AuthModal>
              <button className="bg-background cursor-pointer hover:bg-background hover:bg-opacity-80 duration-100 transition-all ease-in-out w-full px-4 py-2 h-[50px] rounded-lg text-white text-lg flex justify-center items-center gap-x-2">
                <User2 size={24} />
                <span className="font-semibold">Authorization</span>
              </button>
            </AuthModal>
          </div>
        </div>
      </Container> */}
      <Container>
        <nav className="grid grid-cols-3 justify-between items-center gap-x-2   py-3 w-full">
          <div className="col-span-1"></div>
          <ul className="flex col-span-1  justify-center items-center gap-x-1 ">
            {isHome && (
              <li>
                <a
                  className="  text-white text-[.95rem]  bg-slate-950 px-4 py-2 rounded-lg tracking-wide transition-all ease-in-out duration-100"
                  href="/"
                >
                  Home
                </a>
              </li>
            )}
            <li>
              <a
                className="  text-white text-[.95rem] bg-slate-950 px-4 py-2  tracking-wide transition-all ease-in-out duration-100"
                href="/support"
              >
                Support
              </a>
            </li>
            <li>
              <a
                className="  text-white text-[.95rem] bg-slate-950 px-4 py-2   tracking-wide  transition-all ease-in-out duration-100"
                href="/"
              >
                Sell Robox{" "}
              </a>
            </li>
          </ul>
          <div className="flex justify-end items-center">
            <button className="col-span-1 bg-white text-black  cursor-pointer  duration-100 transition-all ease-in-out   px-4 py-1 h-[40px] rounded-xl  text-[0.9rem] flex justify-center items-center gap-x-2 hover:text-slate-500">
              <User2 size={20} />
              <span className="  ">Authorization</span>
            </button>
          </div>
        </nav>
      </Container>
    </header>
  );
};

export default Header;
