import React from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu, User2 } from "lucide-react";
import { menuItems } from "./Header";
import Link from "next/link";
import AuthModal from "./AuthModal";

const MobileMenu = () => {
  return (
    <Sheet>
      <SheetTrigger>
        <Menu />
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle className="mb-5">
            {" "}
            <span className="logo_heading">ibx</span>
          </SheetTitle>
          <SheetDescription>
            <ul>
              {menuItems.map((item) => (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className="font-semibold  pb-4 block text-xl tracking-wide hover:underline transition-all ease-in-out duration-100"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
            <AuthModal>
              <button className="bg-white cursor-pointer hover:bg-gray-100  text-black duration-100 transition-all ease-in-out w-full px-4 py-2 h-[50px] rounded-lg   text-lg flex justify-center items-center gap-x-2">
                <User2 size={24} />
                <span className="font-semibold">Authorization</span>
              </button>
            </AuthModal>
          </SheetDescription>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  );
};

export default MobileMenu;
