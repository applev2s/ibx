import React from "react";

const Container = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) => {
  return (
    <div
      className={`lg:max-w-[1300px] xl:max-w-[1400px] max-w-full w-full mx-auto px-3  ${className}`}
    >
      {children}
    </div>
  );
};

export default Container;
