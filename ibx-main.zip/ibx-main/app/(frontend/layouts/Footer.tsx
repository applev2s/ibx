import { FileText, Shield } from "lucide-react";
import Link from "next/link";

function Footer() {
  return (
    <section
      id="advantages"
      className="relative  bg-zinc-900  w-full overflow-hidden"
    >
      <div className=" bg-[#0042ad] h-24 w-full"></div>

      {/* Wave SVG */}
      <div className="absolute z-10 top-0 rotate-180 left-0 w-full overflow-hidden leading-0 transform">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
          className="relative block w-full h-24"
        >
          <path
            d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"
            className="fill-[#0042ad]"
          ></path>
        </svg>
      </div>

      {/* Footer content */}
      <div className="relative z-10 bg-[#0042ad] py-8 px-4">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <div className="flex flex-col md:flex-row gap-8 mb-4 md:mb-0">
            <a
              href="/terms" // or the correct path to your PDF
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center"
            >
              <div className="bg-white p-2 rounded-md mr-3">
                <FileText className="w-6 h-6 text-[#007bff]" />
              </div>
              <span className="text-white font-bold hover:text-[#007bff] hover:underline">
                User
                <br className="hidden sm:block" /> Agreement
              </span>
            </a>

            {/* Privacy Policy */}
            <a target="_blank" href="/privacy" className="flex items-center">
              <div className="bg-white p-2 rounded-md mr-3">
                <Shield className="w-6 h-6 text-[#007bff]" />
              </div>
              <span className="text-white font-bold hover:text-[#007bff] hover:underline">
                Privacy Policy
              </span>
            </a>
          </div>

          {/* Copyright */}
          <div className="text-white font-bold">© 2023-2025, RbxLine</div>
        </div>
      </div>
    </section>
  );
}

export default Footer;
