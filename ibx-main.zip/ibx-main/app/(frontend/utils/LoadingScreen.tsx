// components/LoadingScreen.tsx
"use client";

import { useEffect, useState } from "react";

export default function LoadingScreen({
  children,
}: {
  children: React.ReactNode;
}) {
  const [showLoading, setShowLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLoading(false);
    }, 500); // 1 second delay

    return () => clearTimeout(timer);
  }, []);

  if (showLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-white">
        <img
          src="/images/loading.gif"
          alt="Loading..."
          className="md:w-[400px] md:h-[300px]"
        />
      </div>
    );
  }

  return <>{children}</>;
}
