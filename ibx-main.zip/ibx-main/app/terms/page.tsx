// import Link from "next/link";
// import Container from "../(frontend/layouts/Container";
// import { BiArrowBack } from "react-icons/bi";
// import Header from "../(frontend/layouts/Header";

// const page = () => {
//   return (
//     <div className="bg-slate-100 min-h-screen pb-10">
//       {/* Header */}
//       <Header isHome={true} />
//       {/* Main Content */}
//       <Container className="  mx-auto px-4 sm:px-6 lg:px-8 py-6">
//         <div className=" rounded-lg shadow-sm p-6 sm:p-8">
//           <h1 className="text-2xl font-bold mb-6">Terms of Service</h1>

//           <p className="text-gray-600 text-sm mb-6">
//             By accessing our services, you agree to comply with and be bound by
//             the following terms and conditions.
//           </p>

//           <div className="space-y-6">
//             {/* Section 1 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">1. General Provisions</h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   1.1 The present terms (hereinafter referred to as the "Terms")
//                   establish the rules for using the Service.
//                 </li>
//                 <li>
//                   1.2 By using our Service, you agree to these Terms in their
//                   entirety.
//                 </li>
//                 <li>
//                   1.3 The Service may be used only in accordance with these
//                   Terms.
//                 </li>
//                 <li>
//                   1.4 The Service provider reserves the right to modify these
//                   Terms.
//                 </li>
//                 <li>
//                   1.5 Continued use of the Service after changes to the Terms
//                   constitutes acceptance of those changes.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 2 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">2. User Obligations</h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   2.1 Users must provide accurate information when using the
//                   Service.
//                 </li>
//                 <li>
//                   2.2 Users must maintain the confidentiality of their account
//                   credentials.
//                 </li>
//                 <li>
//                   2.3 Users are responsible for all activities occurring under
//                   their account.
//                 </li>
//                 <li>
//                   2.4 Users must comply with all applicable laws and
//                   regulations.
//                 </li>
//                 <li>
//                   2.5 Users must not use the Service for any illegal or
//                   unauthorized purpose.
//                 </li>
//                 <li>
//                   2.6 Users must not interfere with the proper functioning of
//                   the Service.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 3 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">3. User Content</h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   3.1 Users are solely responsible for any content they submit,
//                   post, or display on the Service.
//                 </li>
//                 <li>
//                   3.2 The Service does not claim ownership of user content.
//                 </li>
//                 <li>
//                   3.3 By submitting content, users grant the Service a
//                   worldwide, non-exclusive license to use, reproduce, modify,
//                   and display the content.
//                 </li>
//                 <li>
//                   3.4 The Service reserves the right to remove any content that
//                   violates these Terms.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 4 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">
//                 4. Intellectual Property
//               </h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   4.1 The Service and its contents are protected by copyright,
//                   trademark, and other laws.
//                 </li>
//                 <li>
//                   4.2 Our trademarks and trade dress may not be used without our
//                   prior written permission.
//                 </li>
//                 <li>
//                   4.3 Users must respect all intellectual property rights
//                   related to the Service.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 5 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">
//                 5. Limitation of Liability
//               </h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   5.1 The Service is provided "as is" without any warranties,
//                   expressed or implied.
//                 </li>
//                 <li>
//                   5.2 The Service is not liable for any indirect, incidental,
//                   special, consequential, or punitive damages.
//                 </li>
//                 <li>
//                   5.3 The total liability of the Service is limited to the
//                   amount paid by the user in the preceding 12 months.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 6 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">6. Termination</h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   6.1 The Service may terminate or suspend a user's access at
//                   any time for any reason.
//                 </li>
//                 <li>6.2 Users may terminate their account at any time.</li>
//                 <li>
//                   6.3 Upon termination, all provisions of these Terms which
//                   should survive termination shall continue to be in effect.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 7 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">7. Governing Law</h2>
//               <ul className="list-disc pl-5 space-y-2 text-sm">
//                 <li>
//                   7.1 These Terms shall be governed by and construed in
//                   accordance with the laws of the relevant jurisdiction.
//                 </li>
//                 <li>
//                   7.2 Any disputes arising under these Terms shall be subject to
//                   the exclusive jurisdiction of the courts in the relevant
//                   jurisdiction.
//                 </li>
//               </ul>
//             </div>

//             {/* Section 8 */}
//             <div>
//               <h2 className="text-xl font-bold mb-3">8. Contact Information</h2>
//               <p className="text-sm">
//                 If you have any questions about these Terms, please contact us
//                 at support@example.com.
//               </p>
//             </div>
//           </div>

//           <div className="mt-8 pt-4 border-t border-gray-200">
//             <p className="text-sm text-gray-500">Last updated: May 17, 2025</p>
//           </div>
//         </div>
//       </Container>
//     </div>
//   );
// };

// export default page;

import React from "react";
import Header from "../(frontend/layouts/Header";

const page = () => {
  return (
    <div className="  min-h-screen pb-10">
      <Header isHome={true} />
      <main className="lg:max-w-[1400px] w-full mx-auto px-6 py-8">
        <div className=" bg-white shadow-lg rounded-lg border-slate-100 border   p-8 space-y-6">
          <h1 className="text-3xl font-bold">User Agreement</h1>
          <p className="text-gray-600">
            Agreement on the terms of use of information of the company{" "}
            <strong>RbxLine</strong>.
          </p>
          <p className="text-gray-600">
            This Agreement regulates the relationship between the User and the
            copyright holder of the Internet portal.
          </p>

          <h2 className="text-2xl font-bold">Content:</h2>
          <ol className="list-decimal pl-5 space-y-1">
            <li>Terms used</li>
            <li>Subject of the Agreement</li>
            <li>Procedure for entry into force of the Agreement</li>
            <li>
              Rights and obligations of the parties
              <ol className="list-decimal pl-5 space-y-1 mt-1">
                <li>User rights</li>
                <li>User obligations</li>
                <li>The User has no rights</li>
                <li>Operator rights</li>
                <li>Operator obligations</li>
                <li>Limitation of Operator liability</li>
                <li>The Operator does not guarantee</li>
              </ol>
            </li>
            <li>Confidentiality and security</li>
            <li>Additional Paid Services</li>
            <li>Disclaimer of warranties</li>
            <li>Additional provisions</li>
          </ol>

          {/* Section 1 */}
          <section>
            <h2 className="text-2xl font-bold">1. Terms used</h2>
            <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700">
              <li>
                <strong>Operator</strong>: copyright holder of the portal{" "}
                <a
                  href="https://rbxline.ru"
                  className="text-blue-600 hover:underline"
                >
                  https://rbxline.ru
                </a>
                , responsible for administration and maintenance.
              </li>
              <li>
                <strong>User</strong>: an individual visiting or participating
                in projects on the portal.
              </li>
              <li>
                <strong>Portal</strong>: software and hardware systems on the
                Operator's resources; access and usage rights belong exclusively
                to the Operator.
              </li>
              <li>
                <strong>Website</strong>: the site at{" "}
                <a
                  href="https://rbxline.ru"
                  className="text-blue-600 hover:underline"
                >
                  https://rbxline.ru
                </a>
                .
              </li>
              <li>
                <strong>Services</strong>: free offerings provided by the
                Operator within the Portal (excluding Additional Paid Services).
              </li>
              <li>
                <strong>Additional Paid Services</strong>: optional paid
                features within the Portal requested by the User.
              </li>
            </ul>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-2xl font-bold">2. Subject of the Agreement</h2>
            <ol className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                Provision of access to the Portal (Services and Paid Services)
                to an unlimited number of persons under this Agreement.
              </li>
              <li>
                The User understands that portal projects are solely for leisure
                and entertainment, not gambling.
              </li>
            </ol>
          </section>

          {/* Section 3 */}
          <section>
            <h2 className="text-2xl font-bold">
              3. Procedure for entry into force of the Agreement
            </h2>
            <ol className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                Upon acceptance, the User acquires the rights and obligations
                under this Agreement.
              </li>
              <li>
                Acceptance occurs through User registration on the Website.
              </li>
              <li>
                If the User disagrees, they must stop using the Site
                immediately.
              </li>
              <li>
                Use of the Site is allowed only after acceptance of this
                Agreement.
              </li>
              <li>
                The User confirms legal capacity and right to enter this
                Agreement; the Operator is not required to verify registration
                data.
              </li>
              <li>
                To create an account, the User must provide accurate information
                and may participate in contests, draws, and competitions as
                specified.
              </li>
            </ol>
          </section>

          {/* Section 4 */}
          <section>
            <h2 className="text-2xl font-bold">
              4. Rights and obligations of the parties
            </h2>
            <div className="space-y-4 text-sm text-gray-700">
              {/* 4.1 */}
              <div>
                <h3 className="text-xl font-semibold">4.1 User Rights</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Use the Portal for personal, non-commercial purposes.</li>
                  <li>
                    Access all free Services and Additional Paid Services if
                    purchased.
                  </li>
                  <li>Use technical support and contact the Operator.</li>
                  <li>Participate in Portal projects free of charge.</li>
                </ul>
              </div>
              {/* 4.2 */}
              <div>
                <h3 className="text-xl font-semibold">4.2 User Obligations</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Provide accurate information during registration.</li>
                  <li>Secure account credentials and not share them.</li>
                  <li>Provide personal data confirmation if requested.</li>
                  <li>Follow Operator instructions within the Portal.</li>
                  <li>Respect the Operator's intellectual property rights.</li>
                  <li>
                    Use the Portal solely for entertainment without seeking
                    profit.
                  </li>
                </ul>
              </div>
              {/* 4.3 */}
              <div>
                <h3 className="text-xl font-semibold">
                  4.3 The User Has No Right To
                </h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Exploit portal bugs or gain unauthorized access.</li>
                  <li>Restrict other users' access.</li>
                  <li>Engage in fraud or illegal activities.</li>
                  <li>Advertise unrelated content without permission.</li>
                  <li>Use obscene language or distribute harmful materials.</li>
                  <li>Conduct anti-advertising of the Portal.</li>
                </ul>
              </div>
              {/* 4.4 */}
              <div>
                <h3 className="text-xl font-semibold">4.4 Operator Rights</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Modify, limit, or terminate Services at any time without
                    notice.
                  </li>
                  <li>
                    Suspend or change processes on the Portal at its discretion.
                  </li>
                  <li>Apply sanctions for violations of this Agreement.</li>
                  <li>
                    Delete or modify User information posted on the Portal.
                  </li>
                  <li>Track and store User identification and statistics.</li>
                  <li>
                    Send technical, advertising, and other information to Users.
                  </li>
                  <li>Protect its intellectual property by any legal means.</li>
                </ul>
              </div>
              {/* 4.5 */}
              <div>
                <h3 className="text-xl font-semibold">
                  4.5 Operator Obligations
                </h3>
                <ul className="list-decimal pl-5 space-y-1">
                  <li>
                    Ensure availability of Services and Paid Services within the
                    Portal.
                  </li>
                  <li>Respond to User inquiries and resolve disputes.</li>
                </ul>
              </div>
              {/* 4.6 */}
              <div>
                <h3 className="text-xl font-semibold">
                  4.6 Limitation of Operator Liability
                </h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>No liability for damage to User data or equipment.</li>
                  <li>
                    No liability for losses due to Portal unavailability or
                    third-party actions.
                  </li>
                  <li>
                    No liability for User-stated information or lost account
                    access.
                  </li>
                  <li>
                    No liability for lost virtual assets or payment-related
                    expenses.
                  </li>
                  <li>No warranty of uninterrupted operation or data speed.</li>
                </ul>
              </div>
              {/* 4.7 */}
              <div>
                <h3 className="text-xl font-semibold">
                  4.7 The Operator Does Not Guarantee
                </h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Continuous, error-free operation or full satisfaction of
                    User expectations.
                  </li>
                  <li>Quality of Paid Services meeting User expectations.</li>
                  <li>
                    Ability to provide evidence for User violations or
                    sanctions.
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Section 5 */}
          <section>
            <h2 className="text-2xl font-bold">
              5. Confidentiality and Security
            </h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                Confidential information includes data received during
                registration and portal use.
              </li>
              <li>
                Such information is not disclosed to third parties, except by
                law or User consent.
              </li>
              <li>
                Operator secures personal data but does not guarantee against
                third-party breaches.
              </li>
            </ul>
          </section>

          {/* Section 6 */}
          <section>
            <h2 className="text-2xl font-bold">6. Additional Paid Services</h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                Provides advanced features (e.g., in-game currency) upon User
                request and payment.
              </li>
              <li>
                Paid Services are optional and non-refundable once rendered.
              </li>
              <li>
                Operator may store related personal data and lists services and
                costs on the Portal.
              </li>
              <li>User bears all financial costs, commissions, and fees.</li>
              <li>
                Users under 18 require consent from legal representatives;
                Operator may verify age.
              </li>
              <li>
                No disputes permitted regarding Paid Services purchase
                responsibility.
              </li>
            </ul>
          </section>

          {/* Section 7 */}
          <section>
            <h2 className="text-2xl font-bold">7. Disclaimer of Warranties</h2>
            <p className="text-sm text-gray-700 space-y-1">
              ALL SERVICES ON THE PORTAL ARE PROVIDED “AS IS”. THE PORTAL
              DISCLAIMS ANY WARRANTIES REGARDING SERVICES OR VIRTUAL VALUES.
            </p>
            <p className="text-sm text-gray-700 space-y-1">
              THE OPERATOR WARNS THAT EXCESSIVE COMPUTER USE, INCLUDING GAMES,
              CAN BE HARMFUL TO HEALTH. USERS MONITOR THEIR HEALTH AND LIMIT USE
              IF NECESSARY.
            </p>
            <p className="text-sm text-gray-700 space-y-1">
              THE OPERATOR SHALL NOT BE LIABLE FOR INDIRECT, INCIDENTAL, OR
              OTHER DAMAGES, INCLUDING LOST PROFITS, ARISING FROM SERVICES,
              PORTAL MATERIALS, OR THIRD‑PARTY ACTIONS.
            </p>
          </section>

          {/* Section 8 */}
          <section>
            <h2 className="text-2xl font-bold">8. Additional Provisions</h2>
            <ul className="list-decimal pl-5 space-y-1 text-sm text-gray-700">
              <li>
                If local laws restrict use, the User must abstain and is
                responsible for compliance.
              </li>
              <li>
                Invalidity of any clause does not invalidate the Agreement;
                remaining provisions remain enforced.
              </li>
              <li>
                Disputes are first resolved amicably; if unsuccessful, they are
                governed by Russian Federation law.
              </li>
              <li>
                The Operator may amend this Agreement at any time; changes take
                effect upon publication. Users must review it regularly.
              </li>
            </ul>
          </section>

          <p className="text-sm text-gray-500 mt-8 border-t pt-4">
            Last updated: May 17, 2025
          </p>
        </div>
      </main>
    </div>
  );
};

export default page;
