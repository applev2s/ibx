import React from "react";
import ProfileMain from "../(frontend/components/ProfileMain";

const page = () => {
  return <ProfileMain />;
};

export default page;
